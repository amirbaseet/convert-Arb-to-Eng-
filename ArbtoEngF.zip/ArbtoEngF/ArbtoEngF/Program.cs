﻿using System;
using System.Linq;

namespace ArbtoEngF
{
    internal class Program
    {
        static void Main(string[] args)
        {             
            //declaring two char of array and putting in the values for each index of arabic keybord (QWERT) == the english value
                                     //0    1    2    3    4    5    6    7    8    9    10  11    12  13   14   15   16   17   18   19   20   21   22   23   24   25   26   27  28   29   30   31   32    33   
            char[] Eng = new char[] { 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '*', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', ' ' };
            char[] Arb = new char[] { 'ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج', 'د', 'ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك', 'ط', 'ئ', 'ء', 'ؤ', 'ر', '9', 'ى', 'ة', 'و', 'ز', 'ظ', ' ' };
            //declaring string Ar and putting all the arabic indexes in it 
            
            string Ar = "ضصثقفغعهخحجدشسيبلاتنمكطئءؤرلاىةوزظ";
            //puting all The Entered value in a string and convert it to char ofa array
            string Entered;
            //Entered = "İ 5غخعفعلاث";
            //Entered = "لا";
            //Entered = "ضصثقف غعهخح شسيبل اتنم ئءؤر لاىة";
            //Entered = "ئ ء ؤ ر لا ى ة";
            //Entered = "ض ص ث ق ف غ ع ه خ ح ج  د ش س ي ب ل ا ت ن م ك ط ئ ء ؤ ر لا ى ة و ز ظ123456789 !@#$%^&*()_+||";
            Entered = "0 1 2 3 4 5 6 7 8 9 ! @ # $ % ^ & * ( ) _ + | } { P O I U Y T R E W Q A S D F G H J K L : Z X C V B N M < > ? ظ ز و ة ى لا ر ؤ ء ئ ط ك م ن ت ا  ل ب ي س ش د ج ح خ ه ع غ ف ق ث ص ض";
            //Entered = "1256لا!@#$%^&*)(";
            //Entered = "IلالالالالالالالالالالالالاOلاĞÜ;ŞİÖÇ:QAZ:غثس ةغ ةشى ه  مخرث  غخع غخع شقث  ش اثقخ ";
            //Entered = "لا  لا    لا    لا   لا  bj اتناتنانت لا ";
            Entered =  Entered.Replace("لا", Eng[27].ToString());//Because the "لا" causing problemes I Have Direct Repalce it with "b"
            Entered.ToCharArray();
            string final = "";
            Console.WriteLine("length with out space");
            int Enteredlength = Entered.Replace(" ", String.Empty).Length ;
            Console.WriteLine($"Entered.Length = {Enteredlength}");

            for (int i = 0; i < Entered.Length; i++)//making a loop  from 0 to the lengt of entered
            {
                    if (Ar.Contains(Entered[i]) == false || (!char.IsLetterOrDigit(Entered[i])))
                    {
                        final += Entered[i];
                    }
                    else
                    {
                        for (int j = 0; j < Arb.Length; j++)
                        { 
                            if (Entered[i] == Arb[j])
                            {
                                final += Eng[j];
                            }
                        }
                    }
            }
            int finallength = final.Replace(" ", String.Empty).Length;
            Console.WriteLine(final);
            Console.WriteLine($"final.Length = {finallength}");
            if (Enteredlength== finallength)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("All indexes have been converted");
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("All indexes havent been converted");
                Console.ResetColor();

            }
        }
    }
}
