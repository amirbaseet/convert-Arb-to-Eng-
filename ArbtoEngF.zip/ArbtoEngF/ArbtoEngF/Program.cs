﻿using System;
using System.Linq;

namespace ArbtoEngF
{
    internal class Program
    {
        static void Main(string[] args)
        {             
            //declaring two char of array and putting in the values for each index of arabic keybord (QWERT) == the english value
                                     //0    1    2    3    4    5    6    7    8    9    10  11    12  13   14   15   16   17   18   19   20   21   22   23   24   25   26   27  28   29   30   31   32    33   
            char[] Eng = new char[] { 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '*', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', ' ' };
            char[] Arb = new char[] { 'ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج', 'د', 'ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك', 'ط', 'ئ', 'ء', 'ؤ', 'ر', '9', 'ى', 'ة', 'و', 'ز', 'ظ', ' ' };
            //declaring string Ar and putting all the arabic indexes in it 
            
            string Ar = "ضصثقفغعهخحجدشسيبلاتنمكطئءؤرلاىةوزظ";
            //puting all The Entered value in a string and convert it to char ofa array
            string Entered;
            //Entered = "غخع شقث تعسف ش بعؤنثق ";
            //Entered = "İ 5غخعفعلاث";
            //Entered = "لا";
            //Entered = "ضصثقف غعهخح شسيبل اتنم ئءؤر لاىة";
            //Entered = "ئ ء ؤ ر لا ى ة";
            //Entered = "ض ص ث ق ف غ ع ه خ ح ج  د ش س ي ب ل ا ت ن م ك ط ئ ء ؤ ر لا ى ة و ز ظ123456789 !@#$%^&*()_+||";
            Entered = "0 1 2 3 4 5 6 7 8 9 ! @ # $ % ^ & * ( ) _ + | } { P O I U Y T R E W Q A S D F G H J K L : Z X C V B N M < > ? ظ ز و ة ى لا ر ؤ ء ئ ط ك م ن ت ا  ل ب ي س ش د ج ح خ ه ع غ ف ق ث ص ض";
            //Entered = "1256لا!@#$%^&*)(";
            Entered.ToCharArray();
            string B = "لا";
            string final = "";
            int index;
            Console.WriteLine("length with out space");
            Console.WriteLine($"Entered.Length = {Entered.Replace(" ", String.Empty).Length}");
            for (int i = 0; i < Entered.Length; i++)//making a loop  from 0 to the lengt of entered
            {
                if (Entered.Contains(B))//if Entered contains لا 
                {
                    index = Entered.IndexOf(B);//get the index of لا and put it in the int index
                    //if this char Dosent founded at the Ar string
                    if (Ar.Contains(Entered[i])==false  )
                    {
                        final += Entered[i];//add to final string the un defined index
                    }
                    else
                    {

                    for (int j = 0; j < Arb.Length; j++)
                    {
                        if (i==index)//if the i = the index of لا add to final the B
                        {
                            Console.WriteLine("Alert THis is contains 'B'");
                            final += Eng[27] ;
                            i++;
                        }
                        if (Entered[i] == Arb[j] && i != index+1)//if the index founded at Arb and the i != the index+1
                        {
                            final += Eng[j];
                        }
                     
                        }
                    }
                }
                else
                {
                    if (Ar.Contains(Entered[i]) == false || (!char.IsLetterOrDigit(Entered[i])))
                    {
                        final += Entered[i];
                    }
                    else
                    {
                        for (int j = 0; j < Arb.Length; j++)
                        { 
                            if (Entered[i] == Arb[j])
                            {
                                final += Eng[j];
                            }
                        }
                    }
                }
            }
            Console.WriteLine($"final.Length = {final.Replace(" ",String.Empty).Length}");
            Console.WriteLine(final);
        }
    }
}
